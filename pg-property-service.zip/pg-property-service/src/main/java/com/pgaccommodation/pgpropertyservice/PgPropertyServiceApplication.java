package com.pgaccommodation.pgpropertyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PgPropertyServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PgPropertyServiceApplication.class, args);
	}

}
