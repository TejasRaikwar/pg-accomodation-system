import React from 'react'

const MyBookings = () => {
  return (
    <div>
      mybookings
    </div>
  )
}

export default MyBookings
