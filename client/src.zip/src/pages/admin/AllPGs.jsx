import React from 'react'

const AllPGs = () => {
  return (
    <div>
      AllPGs
    </div>
  )
}

export default AllPGs
