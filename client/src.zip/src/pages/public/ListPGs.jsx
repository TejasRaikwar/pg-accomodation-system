import React from 'react'

const ListPGs = () => {
  return (
    <div>
      hello
    </div>
  )
}

export default ListPGs
