import React from 'react'

const PGDetails = () => {
  return (
    <div>
      pgdetails
    </div>
  )
}

export default PGDetails
