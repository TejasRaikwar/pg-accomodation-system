import React from 'react'

const OwnerTenants = () => {
  return (
    <div>
      OwnerTenants
    </div>
  )
}

export default OwnerTenants
